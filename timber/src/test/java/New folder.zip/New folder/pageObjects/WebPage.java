package pageObjects;

public class WebPage {
	
	

}
